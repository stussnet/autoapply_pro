# gpt_writer.py

import openai
from config import OPENAI_API_KEY, USER_PROFILE

openai.api_key = OPENAI_API_KEY

def generate_cover_letter(job_title, company_name):
    prompt = f"""
Write a professional and enthusiastic cover letter for the following job:
Job Title: {job_title}
Company: {company_name}

Use the following candidate profile:
{USER_PROFILE}

The letter should sound confident, human, and ready to contribute. Keep it concise (around 3 paragraphs).
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are an expert resume and cover letter writer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=400
        )
        return response["choices"][0]["message"]["content"].strip()

    except Exception as e:
        return f"❌ Error generating cover letter: {e}"
