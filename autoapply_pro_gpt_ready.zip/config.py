# config.py

# 🚨 Replace this with your real API key before running
OPENAI_API_KEY = "sk-your-real-key-here"

# Your personal background for GPT to include in the cover letter
USER_PROFILE = """
I'm a recent Computer Science graduate with strong interests in AI, automation, and full-stack development.
I'm passionate about solving problems with code, contributing to real-world projects, and working in mission-driven teams.
"""
