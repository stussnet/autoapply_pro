import streamlit as st
import pandas as pd
from scrapers.arbeitnow import scrape_arbeitnow
from gpt_writer import generate_cover_letter

st.title("AutoApply Pro – Arbeitnow Job Scraper + GPT Cover Letters")
st.write("🔍 Search Arbeitnow for remote jobs:")

keyword = st.text_input("Enter job keyword (e.g. python, react, ai)", "python")

if st.button("Search"):
    with st.spinner("Searching for jobs..."):
        jobs = scrape_arbeitnow(keyword)

    if jobs:
        st.success(f"Found {len(jobs)} jobs!")

        # Display results
        for i, job in enumerate(jobs):
            st.markdown(f"### [{job['title']} at {job['company']}]({job['link']})")

            if st.button(f"✍️ Generate Cover Letter #{i+1}", key=f"btn_{i}"):
                letter = generate_cover_letter(job['title'], job['company'])
                st.markdown("#### ✉️ Generated Cover Letter:")
                st.text_area("Cover Letter", letter, height=300)

        # CSV Download
        df = pd.DataFrame(jobs)
        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Results as CSV",
            data=csv,
            file_name=f"{keyword}_arbeitnow_jobs.csv",
            mime="text/csv"
        )
    else:
        st.warning("No jobs found or something went wrong.")
